<footer style="bottom:0;" class="p-2 bg-dark text-white text-center fixed-bottom container-fluid">
  <div class="container">
    <p class="m-2">Copyright &copy; 2021 Yassine El jide & Anass Ousaid</p>
    <a href="#" class="position-absolute bottom-0 end-0 p-1">
      <i class="bi bi-arrow-up-circle h1"></i>
    </a>
  </div>
</footer>
</body>
</html>